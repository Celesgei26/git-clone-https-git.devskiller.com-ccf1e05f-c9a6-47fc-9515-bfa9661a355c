// TO-DO: Implement game below

function getTiles(){
    return document.getElementsByClassName('tile')
}
const tiles = getTiles()

function getPlayers(){
    return document.getElementsByClassName('player')
}
const players = getPlayers()
